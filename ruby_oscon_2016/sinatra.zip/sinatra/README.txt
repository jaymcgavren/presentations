From a terminal, "cd" into this directory. Then run:

    gem install --local sinatra.1.4.7.gem

